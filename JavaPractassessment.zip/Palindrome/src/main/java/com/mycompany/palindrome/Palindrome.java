/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.palindrome;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;
public class Palindrome {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();
            
            if (isPalindrome(number))
                System.out.println(number + " is a palindrome number.");
            else
                System.out.println(number + " is not a palindrome number.");
        }
    }
    
    // Function to check if a number is palindrome
    public static boolean isPalindrome(int num) {
        int reversedNum = 0;
        int originalNum = num;
        
        while (num != 0) {
            int digit = num % 10;
            reversedNum = reversedNum * 10 + digit;
            num /= 10;
        }
        
        return originalNum == reversedNum;
           }
    } 
    

