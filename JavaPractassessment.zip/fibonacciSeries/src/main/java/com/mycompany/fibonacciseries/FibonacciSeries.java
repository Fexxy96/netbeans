/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fibonacciseries;

/**
 *
 * @author Dell-User
 */
public class FibonacciSeries {

    public static void main(String[] args) {
     int maxNumber = 20;
        int previousNumber = 0;
        int nextNumber = 1;
        
        System.out.println("Fibonacci Series up to " + maxNumber + ":");
        
        while (previousNumber <= maxNumber) {
            System.out.print(previousNumber + " ");
            int sum = previousNumber + nextNumber;
            previousNumber = nextNumber;
            nextNumber = sum;   
       }
    }
}
