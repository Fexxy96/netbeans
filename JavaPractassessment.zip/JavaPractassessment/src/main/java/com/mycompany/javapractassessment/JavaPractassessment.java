/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javapractassessment;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;
public class JavaPractassessment {

    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        System.out.println("Enter a number");
        int number = scanner.nextInt();
        
        if(number % 2 == 0) {
            System.out.println(number + " is even.");
        } else {
            System.out.println(number + " is odd");
            
        }
                
                
    }
}
